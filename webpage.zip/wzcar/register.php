<!DOCTYPE HTML>
<html lang="en-US">
<head>
<meta charset="UTF-8">
<title>WZCar Rental</title>
<link rel="stylesheet" type="text/css" href="style.css" media="all" />
<link rel="stylesheet" media="all" href="style/type/folks.css" />
<!--[if IE 7]>
<link rel="stylesheet" type="text/css" href="style/css/ie7.css" media="all" />
<![endif]-->
<script type="text/javascript" src="style/js/jquery-1.5.min.js"></script>
<script type="text/javascript" src="style/js/ddsmoothmenu.js"></script>
<script type="text/javascript" src="style/js/scripts.js"></script>
</head>
  <?php
session_start();
?>

<body>
<div id="container">
<!-- Begin Header Wrapper -->
<div id="page-top">
  <div id="header-wrapper"> 
    <!-- Begin Header -->
    <div id="header">
      <div id="logo"><a href="index.html"><img src="style/image/logo.png" width="146" height="43" alt="Delphic" /></a></div>
      <!-- Logo --> 
      <!-- Begin Menu -->
        <div id="menu-wrapper">
          <div id="smoothmenu1" class="ddsmoothmenu">
            <ul>
              <li><a href="index.html">Home</a>
              <li><a href="login.html">Login</a></li>
              <li><a href="register.html">Register</a></li>
              <li><a href="booking.html">Booking</a></li>
              <li><a href="vehicles.html">Vehicles</a></li>
              <li><a href="location.html">Location</a></li>
              <li><a href="services.html">FAQ/Terms</a></li>
              <li><a href="aboutus.html">About Us</a></li>
              <li><a href="contact.html">Contact</a></li>
            </ul>
          </div>
        </div>
        <!-- End Menu -->
    </div>
    <!-- End Header --> 
  </div>
</div>
<!-- End Header Wrapper --> 

<!-- Begin Wrapper -->
<div id="wrapper"> 
  
  <!-- Begin Content -->
  <div class="content">
    <h1>&nbsp;</h1>
    <div class="one-half">
      <p><span class="dropcap">Register</span></p>
      <p>&nbsp;</p>
	  <?php
          $username = trim($_POST['name']);
          $password = trim($_POST['password']);
          $tel = trim($_POST['tel']);
          $email = trim($_POST['email']);
		  $_SESSION['name'] = $username;
          $_SESSION['email'] = $email;

         $connect = mysql_connect("localhost", "it6413_richard", "79407");
        mysql_select_db("it6413_richard");


         $adduser ="INSERT INTO `users`(`Name`, `Password`) VALUES ($username,$password)";
         $runadd = mysql_query($adduser);
         $row = mysql_fetch_assoc($runadd);

         if (empty($username) || empty($password) || empty($tel)  || empty($email))
          {
          
          print"no empty form";
          
		 
		}
        else
        {
		print"welcome!";
        }
        ?>
      <form method="post" action="register.php" onSubmit="">
      <p>Name 
        :
        <input type="text" name="name" id="textfield">
      </p>
      <p>
        <label for="password">Password:</label>
        <input type="password" name="password" id="password">
      </p>
      <p>
        <label for="tel">Tel:</label>
        <input type="tel" name="tel" id="tel">
      </p>
      <p>
        <label for="email">Email:</label>
        <input type="email" name="email" id="email">
      </p>
      <p>
        <input type="submit" name="submit" id="submit" value="submit">
      </p>
      </form>
    </div>
    <div class="clear"></div>
    <br />
    <div class="clear"></div>
    <br />
    <div class="clear"></div>
    <br />
  </div>
  <!-- End Wrapper -->
  
  <div class="clearfix"></div>
  <div class="push"></div>
</div>

<!-- Begin Footer -->
<div id="footer-wrapper">
  <div id="footer">
    <div id="footer-content"> 
      
      <!-- Begin Copyright -->
      <div id="copyright">
        <p>© Copyright 2011 WZCar Rental| Zexiang Zhao</p>
      </div>
      <!-- End Copyright --> 
      
      <!-- Begin Social Icons -->
      <div id="socials">
        <ul>
          <li><a href="#"></a><img src="style/images/icon-rss.png" alt="" /></li>
          <li><a href="#"></a><img src="style/images/icon-twitter.png" alt="" /></li>
          <li><a href="#"></a><img src="style/images/icon-dribble.png" alt="" /></li>
          <li><a href="#"></a><img src="style/images/icon-tumblr.png" alt="" /></li>
          <li><a href="#"></a><img src="style/images/icon-flickr.png" alt="" /></li>
          <li><a href="#"></a><img src="style/images/icon-facebook.png" alt="" /></li>
        </ul>
      </div>
      <!-- End Social Icons --> 
      
    </div>
  </div>
</div>
<!-- End Footer -->
</body>
</html>