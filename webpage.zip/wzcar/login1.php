<!DOCTYPE HTML>
<html lang="en-US">
<head>
<meta charset="UTF-8">
<title>WZCar Rental</title>
<link rel="stylesheet" type="text/css" href="style.css" media="all" />
<link rel="stylesheet" media="all" href="style/type/folks.css" />
<!--[if IE 7]>
<link rel="stylesheet" type="text/css" href="style/css/ie7.css" media="all" />
<![endif]-->
<script type="text/javascript" src="style/js/jquery-1.5.min.js"></script>
<script type="text/javascript" src="style/js/ddsmoothmenu.js"></script>
<script type="text/javascript" src="style/js/scripts.js"></script>
</head>

      <?php
session_start();
?>



<body>
<div id="container">
<!-- Begin Header Wrapper -->
<div id="page-top">
  <div id="header-wrapper"> 
    <!-- Begin Header -->
    <div id="header">
      <div id="logo"><a href="index.html"><img src="style/image/logo.png" width="146" height="43" alt="Delphic" /></a></div>
      <!-- Logo --> 
      <!-- Begin Menu -->
        <div id="menu-wrapper">
          <div id="smoothmenu1" class="ddsmoothmenu">
            <ul>
              <li><a href="index.html">Home</a>
              <li><a href="login.html">Login</a></li>
              <li><a href="register.html">Register</a></li>
              <li><a href="booking.html">Booking</a></li>
              <li><a href="vehicles.html">Vehicles</a></li>
              <li><a href="location.html">Location</a></li>
              <li><a href="services.html">FAQ/Terms</a></li>
              <li><a href="aboutus.html">About Us</a></li>
              <li><a href="contact.html">Contact</a></li>
            </ul>
          </div>
        </div>
        <!-- End Menu -->
    </div>
    <!-- End Header --> 
  </div>
</div>
<!-- End Header Wrapper --> 

<!-- Begin Wrapper -->
<div id="wrapper"> 
  
  <!-- Begin Content -->
  <div class="content">
    <h1>&nbsp;</h1>
    <div class="one-half">
      <p><span class="dropcap">Login Here</span></p>
      <p>

	<?php
	session_start();

	$username = $_POST['name'];
	$password = $_POST['password'];
	$coupon=$_post['number'];
	
	
	$touch = mysql_connect("localhost", "it6413_richard", "79407");
	if(!$touch) { print mysql_error(); }
	$touch_db = mysql_select_db("it6413_richard");
	if(!$touch_db) { print mysql_error(); }

	$query = "SELECT `name`, `password` FROM `users` WHERE `name` = $username";
	$result = mysql_query($query);
	$row = mysql_fetch_assoc($result);

	//check if the user exists

	if
	($row['name'] == $username && $row['password'] == $password) 
	{
	$query = "SELECT `coupon`FROM `coupon` WHERE `coupon` = $coupon";
	$_SESSION['name'] = $row['name'];
	print "<p>Welcome!!</p>";
	?>
	<form method="post" action="" >
      <p>Enter your coupon number
        <label for="number">number</label>
        <input type="number" name="number">
      </p>
      <p>
        <button type="button" onclick="alert('You get 20% off!')" id="button">Click Me!</button>
		<input type="submit" action="index.html" name="submit" value="logout">
      </p>
      </form> 
	 <?php
	} 
	else 
	{
		print "<p>Incorrect details. Please try again!</p>";
	?>
	</p>
      <form method="post" action="login1.php" >
      <p>Name 
        :
        <input type="text" name="name">
      </p>
      <p>Password
        <label for="password">Password:</label>
        <input type="password" name="password">
      </p>
      <p>
        <input type="submit" name="submit">
      </p>
      </form>
     <?php
	}
	mysql_close();

	?>
    
      
    </div>
    <div class="clear"></div>
    <br />
    <br />
    <h5><br />
    </h5>
  </div>
  <!-- End Wrapper -->
  
  <div class="clearfix"></div>
  <div class="push"></div>
</div>

<!-- Begin Footer -->
<div id="footer-wrapper">
  <div id="footer">
    <div id="footer-content"> 
      
      <!-- Begin Copyright -->
      <div id="copyright">
        <p>© Copyright 2011 WZCar Rental| Zexiang Zhao</p>
      </div>
      <!-- End Copyright --> 
      
      <!-- Begin Social Icons -->
      <div id="socials">
        <ul>
          <li><a href="#"></a><img src="style/images/icon-rss.png" alt="" /></li>
          <li><a href="#"></a><img src="style/images/icon-twitter.png" alt="" /></li>
          <li><a href="#"></a><img src="style/images/icon-dribble.png" alt="" /></li>
          <li><a href="#"></a><img src="style/images/icon-tumblr.png" alt="" /></li>
          <li><a href="#"></a><img src="style/images/icon-flickr.png" alt="" /></li>
          <li><a href="#"></a><img src="style/images/icon-facebook.png" alt="" /></li>
        </ul>
      </div>
      <!-- End Social Icons --> 
      
    </div>
  </div>
</div>
<!-- End Footer -->
</body>
</html>